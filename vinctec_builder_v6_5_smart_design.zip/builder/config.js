/* Shared builder configuration. Keep settings here as V6.4 grows. */
window.VinctecBuilderConfig = Object.freeze({
  version: "6.5",
  componentCounts: Object.freeze({ hero: 3, services: 3, testimonial: 3, cta: 3, footer: 3 }),
  pages: Object.freeze(["index.html", "about.html", "services.html", "contact.html"]),
  outputFiles: Object.freeze(["index.html", "about.html", "services.html", "contact.html", "style.css"])
});
