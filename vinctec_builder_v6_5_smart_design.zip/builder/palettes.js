/* Palette registry for upcoming V6.4 design controls. */
window.VinctecBuilderPalettes = Object.freeze({
  apple: Object.freeze({ label: "Apple Light", background: "#f5f5f7", surface: "#ffffff", text: "#1d1d1f", muted: "#6e6e73", accent: "#0071e3" }),
  midnight: Object.freeze({ label: "Midnight", background: "#070b14", surface: "#101827", text: "#f8fafc", muted: "#a8b3c7", accent: "#60a5fa" }),
  luxury: Object.freeze({ label: "Luxury Gold", background: "#090806", surface: "#17140f", text: "#fffaf0", muted: "#c8bda7", accent: "#d4af37" }),
  emerald: Object.freeze({ label: "Emerald", background: "#06120f", surface: "#0c211b", text: "#ecfdf5", muted: "#a7c7bc", accent: "#34d399" })
});
