/* Animation registry for future component-level selection. */
window.VinctecBuilderAnimations = Object.freeze({
  fade: Object.freeze({ label: "Fade Up", className: "animation-fade" }),
  slide: Object.freeze({ label: "Slide In", className: "animation-slide" }),
  zoom: Object.freeze({ label: "Soft Zoom", className: "animation-zoom" }),
  none: Object.freeze({ label: "None", className: "animation-none" })
});
