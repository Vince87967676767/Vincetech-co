Vinctec Builder Pro V6.5 — Premium Design Intelligence

Upload admin.html and the complete builder folder together.

New in V6.5:
- Smart business-type detection
- Design style, personality and audience controls
- Colour palette engine
- Typography engine
- Animation selection
- Automatic industry-based component decisions
- Manual component overrides remain available
- Existing dashboard, preview, downloads and ZIP workflow preserved

Keep V6.4 as a backup until V6.5 is tested on your hosting.
